package prototipo.proyectofinal;

public interface Entrante {
    public void notificarLlegada();
    public void registrar();
    
}
