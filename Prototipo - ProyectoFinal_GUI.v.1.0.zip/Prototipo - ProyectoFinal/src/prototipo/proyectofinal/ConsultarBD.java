package prototipo.proyectofinal;

public interface ConsultarBD {
    public void consultarVisitantes();
    public void consultarPaquetes();
}
